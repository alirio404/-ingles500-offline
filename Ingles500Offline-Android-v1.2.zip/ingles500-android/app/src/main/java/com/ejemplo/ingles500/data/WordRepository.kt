package com.ejemplo.ingles500.data

import android.content.Context
import androidx.room.withTransaction
import com.ejemplo.ingles500.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

 data class StudyStats(
    val totalWords: Int,
    val learnedWords: Int,
    val dueWords: Int,
    val reviewedWords: Int
) {
    val percentage: Int
        get() = if (totalWords == 0) 0 else (learnedWords * 100 / totalWords).coerceIn(0, 100)
}

class WordRepository(
    private val database: AppDatabase,
    private val appContext: Context
) {
    private val words = database.wordDao()
    private val progress = database.progressDao()
    private val preferences = appContext.getSharedPreferences("seed_control", Context.MODE_PRIVATE)

    /** Apply new bundled vocabulary by ID without replacing parent rows or deleting progress. */
    suspend fun ensureSeeded() {
        val bundledWords = SeedImporter.loadWords(appContext)
        val appliedVersion = preferences.getInt(KEY_SEED_VERSION, 0)
        if (words.count() == 0) {
            words.insertAll(bundledWords)
        } else if (appliedVersion < BuildConfig.SEED_VERSION) {
            words.insertAll(bundledWords)
            words.updateAll(bundledWords)
        }
        preferences.edit().putInt(KEY_SEED_VERSION, BuildConfig.SEED_VERSION).apply()
    }

    suspend fun getAllWords(): List<WordEntity> = words.getAllOnce()

    suspend fun getStudyOrder(): List<WordEntity> = words.getStudyOrder(System.currentTimeMillis())

    fun observeStats(): Flow<StudyStats> {
        val now = System.currentTimeMillis()
        return combine(
            words.observeCount(),
            progress.observeLearnedCount(),
            progress.observeDueCount(now),
            progress.observeReviewedCount()
        ) { total, learned, due, reviewed ->
            StudyStats(total, learned, due, reviewed)
        }
    }

    suspend fun recordAnswer(wordId: Int, correct: Boolean, mode: String = "FLASHCARD") =
        withContext(NonCancellable) {
            // Finish the local write even if the Fragment/ViewModel is closed immediately after an answer.
            val now = System.currentTimeMillis()
            val previous = progress.getByWordId(wordId)
            val next = if (correct) {
                val correctCount = (previous?.correctCount ?: 0) + 1
                val streak = (previous?.streak ?: 0) + 1
                val oldInterval = previous?.intervalDays ?: 0
                val newInterval = when (oldInterval) {
                    0 -> 1
                    1 -> 3
                    3 -> 7
                    else -> (oldInterval * 2).coerceAtMost(30)
                }
                ProgressEntity(
                    wordId = wordId,
                    correctCount = correctCount,
                    wrongCount = previous?.wrongCount ?: 0,
                    intervalDays = newInterval,
                    nextReviewAt = now + TimeUnit.DAYS.toMillis(newInterval.toLong()),
                    lastReviewedAt = now,
                    learned = streak >= 3,
                    streak = streak,
                    attemptCount = (previous?.attemptCount ?: 0) + 1,
                    lastMode = mode
                )
            } else {
                ProgressEntity(
                    wordId = wordId,
                    correctCount = previous?.correctCount ?: 0,
                    wrongCount = (previous?.wrongCount ?: 0) + 1,
                    intervalDays = 0,
                    nextReviewAt = now + TimeUnit.MINUTES.toMillis(10),
                    lastReviewedAt = now,
                    learned = false,
                    streak = 0,
                    attemptCount = (previous?.attemptCount ?: 0) + 1,
                    lastMode = mode
                )
            }
            progress.upsert(next)
        }

    /** Export all learning state as portable JSON. The user chooses where to save it. */
    suspend fun exportProgressJson(): String {
        val rows = progress.getAllOnce()
        val payload = JSONArray()
        rows.forEach { item ->
            payload.put(JSONObject().apply {
                put("wordId", item.wordId)
                put("correctCount", item.correctCount)
                put("wrongCount", item.wrongCount)
                put("intervalDays", item.intervalDays)
                put("nextReviewAt", item.nextReviewAt)
                put("lastReviewedAt", item.lastReviewedAt)
                put("learned", item.learned)
                put("streak", item.streak)
                put("attemptCount", item.attemptCount)
                put("lastMode", item.lastMode)
            })
        }
        return JSONObject().apply {
            put("format", BACKUP_FORMAT)
            put("schemaVersion", 2)
            put("exportedAt", System.currentTimeMillis())
            put("progress", payload)
        }.toString(2)
    }

    /** Restore a validated snapshot in one database transaction. Invalid files change nothing. */
    suspend fun restoreProgressJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == BACKUP_FORMAT) { "El archivo no es una copia de Inglés 500." }
        val source = root.optJSONArray("progress") ?: throw IllegalArgumentException("La copia no contiene progreso.")
        require(source.length() <= 500) { "La copia contiene demasiados registros." }
        val validWordIds = words.getAllOnce().map { it.id }.toSet()
        val seen = HashSet<Int>()
        val restored = ArrayList<ProgressEntity>(source.length())
        for (i in 0 until source.length()) {
            val item = source.getJSONObject(i)
            val id = item.getInt("wordId")
            require(id in validWordIds && seen.add(id)) { "La copia contiene un ID de palabra no válido o duplicado." }
            restored += ProgressEntity(
                wordId = id,
                correctCount = item.optInt("correctCount", 0).coerceAtLeast(0),
                wrongCount = item.optInt("wrongCount", 0).coerceAtLeast(0),
                intervalDays = item.optInt("intervalDays", 0).coerceIn(0, 30),
                nextReviewAt = item.optLong("nextReviewAt", 0L).coerceAtLeast(0L),
                lastReviewedAt = item.optLong("lastReviewedAt", 0L).coerceAtLeast(0L),
                learned = item.optBoolean("learned", false),
                streak = item.optInt("streak", 0).coerceAtLeast(0),
                attemptCount = item.optInt("attemptCount", 0).coerceAtLeast(0),
                lastMode = item.optString("lastMode", "FLASHCARD").take(30)
            )
        }
        database.withTransaction {
            progress.clearAll()
            progress.insertAll(restored)
        }
    }

    companion object {
        private const val KEY_SEED_VERSION = "applied_seed_version"
        private const val BACKUP_FORMAT = "ingles500-progress-backup"
    }
}
