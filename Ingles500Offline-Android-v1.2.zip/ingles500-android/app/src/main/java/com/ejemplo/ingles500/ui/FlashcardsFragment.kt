package com.ejemplo.ingles500.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.ejemplo.ingles500.LearningApp
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.databinding.FragmentFlashcardsBinding
import java.util.Locale

class FlashcardsFragment : Fragment() {
    private var _binding: FragmentFlashcardsBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: FlashcardsViewModel
    private var currentWordId: Int? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startOnDeviceSpeech() else toast("Se necesita permiso de micrófono para responder hablando.")
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFlashcardsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val repo = (requireActivity().application as LearningApp).repository
        viewModel = ViewModelProvider(this, RepositoryViewModelFactory(repo))[FlashcardsViewModel::class.java]

        viewModel.currentWord.observe(viewLifecycleOwner) { word ->
            currentWordId = word?.id
            binding.tvWord.text = word?.english.orEmpty()
            binding.tvTranslation.text = word?.spanish.orEmpty()
            binding.tvExample.text = word?.example.orEmpty()
            binding.etCardAnswer.text?.clear()
            binding.translationPanel.visibility = View.GONE
            binding.btnNext.isEnabled = false
            binding.btnCheckAnswer.isEnabled = word != null
            binding.btnSkipCard.isEnabled = word != null
        }
        viewModel.counter.observe(viewLifecycleOwner) { binding.tvCardCounter.text = it }
        viewModel.translationUnlocked.observe(viewLifecycleOwner) { unlocked ->
            binding.translationPanel.visibility = if (unlocked) View.VISIBLE else View.GONE
            binding.btnNext.isEnabled = unlocked
            binding.btnCheckAnswer.isEnabled = !unlocked
            binding.btnSpeakAnswer.isEnabled = !unlocked && supportsOfflineSpeech()
            binding.etCardAnswer.isEnabled = !unlocked
            binding.btnSkipCard.isEnabled = !unlocked
        }
        viewModel.answerFeedback.observe(viewLifecycleOwner) { feedback ->
            binding.tvCardFeedback.text = feedback
            when {
                feedback.startsWith("¡Correcto") -> LocalAudioPlayer.playEffect(requireContext(), "correct")
                feedback.startsWith("Todavía") -> LocalAudioPlayer.playEffect(requireContext(), "wrong")
            }
        }

        binding.btnAudio.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            currentWordId?.let { LocalAudioPlayer.playWord(requireContext(), it) }
        }
        binding.btnCheckAnswer.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            viewModel.checkTypedAnswer(binding.etCardAnswer.text?.toString().orEmpty())
        }
        binding.btnSpeakAnswer.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startOnDeviceSpeech()
            } else {
                microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        binding.btnSkipCard.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "page")
            viewModel.skipCard()
        }
        binding.btnNext.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            viewModel.nextAfterCorrect()
        }
        binding.btnSpeakAnswer.visibility = if (supportsOfflineSpeech()) View.VISIBLE else View.GONE
    }

    private fun supportsOfflineSpeech(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        SpeechRecognizer.isOnDeviceRecognitionAvailable(requireContext())

    private fun startOnDeviceSpeech() {
        if (!supportsOfflineSpeech()) {
            toast("Este dispositivo no ofrece reconocimiento de voz local. Puedes escribir la respuesta.")
            return
        }
        val recognizer = speechRecognizer ?: SpeechRecognizer.createOnDeviceSpeechRecognizer(requireContext()).also {
            speechRecognizer = it
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { binding.tvCardFeedback.text = "Escuchando…" }
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() { binding.tvCardFeedback.text = "Comprobando pronunciación…" }
            override fun onError(error: Int) { toast("No pude reconocer la palabra. Inténtalo otra vez o escríbela.") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (spoken.isNullOrBlank()) toast("No se detectó una palabra.") else viewModel.checkSpokenAnswer(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.startListening(intent)
    }

    private fun toast(message: String) = Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()

    override fun onDestroyView() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        LocalAudioPlayer.releasePronunciation()
        super.onDestroyView()
        _binding = null
    }
}
