package com.ejemplo.ingles500.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.ejemplo.ingles500.LearningApp
import com.ejemplo.ingles500.R
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.databinding.FragmentWritingBinding

class WritingFragment : Fragment() {
    private var _binding: FragmentWritingBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: WritingViewModel
    private var wordId: Int? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentWritingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val repo = (requireActivity().application as LearningApp).repository
        viewModel = ViewModelProvider(this, RepositoryViewModelFactory(repo))[WritingViewModel::class.java]

        viewModel.currentWord.observe(viewLifecycleOwner) { word ->
            wordId = word?.id
            binding.tvSpanishPrompt.text = word?.spanish ?: getString(R.string.loading)
            binding.tvSentence.text = word?.let { makeBlankSentence(it.english, it.example) }.orEmpty()
            binding.inputAnswer.setText("")
            binding.inputAnswer.isEnabled = true
            binding.btnCheck.isEnabled = true
        }
        viewModel.feedback.observe(viewLifecycleOwner) { feedback ->
            binding.tvFeedback.text = feedback.orEmpty()
        }
        viewModel.isCorrect.observe(viewLifecycleOwner) { correct ->
            when (correct) {
                true -> {
                    binding.inputAnswer.isEnabled = false
                    binding.btnCheck.isEnabled = false
                    LocalAudioPlayer.playEffect(requireContext(), "correct")
                }
                false -> {
                    // A wrong attempt is feedback, not the end of the exercise: allow retries.
                    binding.inputAnswer.isEnabled = true
                    binding.btnCheck.isEnabled = true
                    LocalAudioPlayer.playEffect(requireContext(), "wrong")
                }
                null -> Unit
            }
        }
        binding.btnCheck.setOnClickListener { LocalAudioPlayer.playEffect(requireContext(), "click"); viewModel.checkAnswer(binding.inputAnswer.text?.toString().orEmpty()) }
        binding.btnNext.setOnClickListener { LocalAudioPlayer.playEffect(requireContext(), "page"); viewModel.next() }
        binding.btnHear.setOnClickListener { LocalAudioPlayer.playEffect(requireContext(), "click"); wordId?.let { LocalAudioPlayer.playWord(requireContext(), it) } }
    }

    private fun makeBlankSentence(word: String, sentence: String): String {
        val regex = Regex("\\b${Regex.escape(word)}\\b", RegexOption.IGNORE_CASE)
        return if (regex.containsMatchIn(sentence)) regex.replace(sentence, "________")
        else getString(R.string.write_example_fallback, "________")
    }

    override fun onDestroyView() {
        LocalAudioPlayer.releasePronunciation()
        super.onDestroyView()
        _binding = null
    }
}
