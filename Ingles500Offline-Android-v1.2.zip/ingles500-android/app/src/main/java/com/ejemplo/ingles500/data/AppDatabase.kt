package com.ejemplo.ingles500.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [WordEntity::class, ProgressEntity::class],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun progressDao(): ProgressDao

    companion object {
        // Migration from the original APK (database version 1). Existing rows remain intact.
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE progress ADD COLUMN streak INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE progress ADD COLUMN attemptCount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE progress ADD COLUMN lastMode TEXT NOT NULL DEFAULT 'FLASHCARD'")
                // Keep old learned flags meaningful after the new streak-based rule.
                db.execSQL("UPDATE progress SET streak = 3 WHERE learned = 1")
                db.execSQL("UPDATE progress SET attemptCount = correctCount + wrongCount")
            }
        }
    }
}
