package com.ejemplo.ingles500.ui

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.ejemplo.ingles500.LearningApp
import com.ejemplo.ingles500.R
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.data.WordEntity
import com.ejemplo.ingles500.databinding.FragmentGamesBinding
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip

class GamesFragment : Fragment() {
    private var _binding: FragmentGamesBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: GamesViewModel
    private var currentMode = MODE_QUIZ

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGamesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val repo = (requireActivity().application as LearningApp).repository
        viewModel = ViewModelProvider(this, RepositoryViewModelFactory(repo))[GamesViewModel::class.java]

        binding.btnModeQuiz.setOnClickListener { click(); currentMode = MODE_QUIZ; showMode(); viewModel.setReverseMode(false) }
        binding.btnModeReverse.setOnClickListener { click(); currentMode = MODE_REVERSE; showMode(); viewModel.setReverseMode(true) }
        binding.btnModeMatch.setOnClickListener { click(); currentMode = MODE_MATCH; showMode(); viewModel.newMatchRound() }
        binding.btnModePhrase.setOnClickListener { click(); currentMode = MODE_PHRASE; showMode(); viewModel.newPhraseChallenge() }
        binding.btnNextQuestion.setOnClickListener { click(); viewModel.nextQuestion() }
        binding.btnNewMatch.setOnClickListener { click(); viewModel.newMatchRound() }
        binding.btnCheckPhrase.setOnClickListener { click(); viewModel.checkPhrase() }
        binding.btnClearPhrase.setOnClickListener { click(); viewModel.clearPhrase(); renderPhraseTiles(viewModel.phraseChallenge.value) }
        binding.btnNewPhrase.setOnClickListener { click(); viewModel.newPhraseChallenge() }

        viewModel.question.observe(viewLifecycleOwner) { question ->
            if (question == null) return@observe
            binding.tvQuestion.text = question.prompt
            binding.optionsContainer.removeAllViews()
            question.options.forEach { option ->
                val button = MaterialButton(requireContext()).apply {
                    text = option
                    isAllCaps = false
                    cornerRadius = resources.getDimensionPixelSize(R.dimen.button_corner_radius)
                    setOnClickListener { click(); viewModel.choose(option) }
                }
                val params = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                params.bottomMargin = resources.getDimensionPixelSize(R.dimen.option_spacing)
                binding.optionsContainer.addView(button, params)
            }
        }
        viewModel.feedback.observe(viewLifecycleOwner) { binding.tvGameFeedback.text = it.orEmpty() }
        viewModel.answered.observe(viewLifecycleOwner) { answered ->
            binding.btnNextQuestion.isEnabled = answered
            for (index in 0 until binding.optionsContainer.childCount) {
                binding.optionsContainer.getChildAt(index).isEnabled = !answered
            }
            if (answered) LocalAudioPlayer.playEffect(requireContext(), if (viewModel.feedback.value.orEmpty().startsWith("¡Muy bien")) "correct" else "wrong")
        }

        viewModel.matchRound.observe(viewLifecycleOwner) { renderMatchRound(it) }
        viewModel.matchedIds.observe(viewLifecycleOwner) { renderMatchSelections() }
        viewModel.selectedMatchId.observe(viewLifecycleOwner) { renderMatchSelections() }
        viewModel.matchFeedback.observe(viewLifecycleOwner) { feedback ->
            binding.tvMatchFeedback.text = feedback.orEmpty()
            when {
                feedback?.startsWith("¡Pareja correcta") == true || feedback?.startsWith("¡Completaste") == true ->
                    LocalAudioPlayer.playEffect(requireContext(), "correct")
                feedback?.startsWith("No coinciden") == true -> LocalAudioPlayer.playEffect(requireContext(), "wrong")
            }
        }
        viewModel.matchComplete.observe(viewLifecycleOwner) { binding.btnNewMatch.isEnabled = it }

        viewModel.phraseChallenge.observe(viewLifecycleOwner) { challenge ->
            binding.tvPhraseTarget.text = challenge?.word?.english.orEmpty()
            binding.tvPhraseTranslation.text = challenge?.word?.spanish.orEmpty()
            renderPhraseTiles(challenge)
        }
        viewModel.phraseText.observe(viewLifecycleOwner) { binding.tvPhraseAssembly.text = it.ifBlank { getString(R.string.phrase_empty) } }
        viewModel.phraseFeedback.observe(viewLifecycleOwner) { feedback ->
            binding.tvPhraseFeedback.text = feedback
            when {
                feedback.startsWith("¡Muy bien") -> LocalAudioPlayer.playEffect(requireContext(), "correct")
                feedback.startsWith("Aún") -> LocalAudioPlayer.playEffect(requireContext(), "wrong")
            }
        }
        viewModel.phraseAnswered.observe(viewLifecycleOwner) { answered ->
            binding.btnNewPhrase.isEnabled = answered
            binding.btnCheckPhrase.isEnabled = !answered
            binding.btnClearPhrase.isEnabled = !answered
        }
        showMode()
    }

    private fun click() = LocalAudioPlayer.playEffect(requireContext(), "click")

    private fun showMode() {
        binding.quizPanel.visibility = if (currentMode == MODE_QUIZ || currentMode == MODE_REVERSE) View.VISIBLE else View.GONE
        binding.matchPanel.visibility = if (currentMode == MODE_MATCH) View.VISIBLE else View.GONE
        binding.phrasePanel.visibility = if (currentMode == MODE_PHRASE) View.VISIBLE else View.GONE
        if (currentMode == MODE_PHRASE || currentMode == MODE_MATCH) LocalAudioPlayer.playEffect(requireContext(), "page")
    }

    private fun renderMatchRound(round: MatchRound?) {
        if (round == null) return
        binding.matchEnglishContainer.removeAllViews()
        binding.matchSpanishContainer.removeAllViews()
        round.left.forEach { binding.matchEnglishContainer.addView(createMatchButton(it, english = true)) }
        round.right.forEach { binding.matchSpanishContainer.addView(createMatchButton(it, english = false)) }
        renderMatchSelections()
    }

    private fun createMatchButton(word: WordEntity, english: Boolean): MaterialButton {
        return MaterialButton(requireContext()).apply {
            text = if (english) word.english else word.spanish
            tag = word.id
            isAllCaps = false
            cornerRadius = resources.getDimensionPixelSize(R.dimen.button_corner_radius)
            val params = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = resources.getDimensionPixelSize(R.dimen.option_spacing)
            layoutParams = params
            setOnClickListener {
                click()
                if (english) viewModel.selectEnglishForMatch(word.id) else viewModel.selectSpanishForMatch(word.id)
            }
        }
    }

    private fun renderMatchSelections() {
        if (_binding == null) return
        val matched = viewModel.matchedIds.value.orEmpty()
        val selected = viewModel.selectedMatchId.value
        listOf(binding.matchEnglishContainer, binding.matchSpanishContainer).forEach { container ->
            for (index in 0 until container.childCount) {
                val button = container.getChildAt(index) as? MaterialButton ?: continue
                val id = button.tag as? Int ?: continue
                button.isEnabled = !matched.contains(id)
                button.backgroundTintList = when {
                    matched.contains(id) -> ColorStateList.valueOf(requireContext().getColor(R.color.match_done))
                    id == selected && container.id == R.id.matchEnglishContainer -> ColorStateList.valueOf(requireContext().getColor(R.color.palette_gold))
                    else -> null
                }
                if (matched.contains(id)) button.setTextColor(requireContext().getColor(android.R.color.white))
            }
        }
    }

    private fun renderPhraseTiles(challenge: PhraseChallenge?) {
        if (_binding == null || challenge == null) return
        binding.phraseTilesContainer.removeAllViews()
        challenge.tiles.forEach { tile ->
            val button = Chip(requireContext()).apply {
                text = tile.text
                isAllCaps = false
                isCheckable = false
                isClickable = true
                setOnClickListener {
                    click()
                    isEnabled = false
                    viewModel.selectPhraseTile(tile.id)
                }
            }
            val params = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.setMargins(4, 4, 4, 4)
            binding.phraseTilesContainer.addView(button, params)
        }
        binding.btnNewPhrase.isEnabled = viewModel.phraseAnswered.value == true
        binding.btnCheckPhrase.isEnabled = viewModel.phraseAnswered.value != true
        binding.btnClearPhrase.isEnabled = viewModel.phraseAnswered.value != true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val MODE_QUIZ = 0
        private const val MODE_REVERSE = 1
        private const val MODE_MATCH = 2
        private const val MODE_PHRASE = 3
    }
}
