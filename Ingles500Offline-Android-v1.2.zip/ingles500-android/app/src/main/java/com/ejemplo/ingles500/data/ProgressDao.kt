package com.ejemplo.ingles500.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM progress WHERE wordId = :wordId LIMIT 1")
    suspend fun getByWordId(wordId: Int): ProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: ProgressEntity)

    @Query("SELECT * FROM progress ORDER BY wordId")
    suspend fun getAllOnce(): List<ProgressEntity>

    @Query("DELETE FROM progress")
    suspend fun clearAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ProgressEntity>)

    @Query("SELECT COUNT(*) FROM progress WHERE learned = 1")
    fun observeLearnedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM progress WHERE nextReviewAt <= :now")
    fun observeDueCount(now: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM progress")
    fun observeReviewedCount(): Flow<Int>
}
