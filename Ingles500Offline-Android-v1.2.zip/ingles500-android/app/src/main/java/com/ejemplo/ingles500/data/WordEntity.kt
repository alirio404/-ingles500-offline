package com.ejemplo.ingles500.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "words")
data class WordEntity(
    @PrimaryKey val id: Int,
    val english: String,
    val spanish: String,
    val example: String,
    val category: String
)
