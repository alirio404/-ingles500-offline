package com.ejemplo.ingles500.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.ejemplo.ingles500.LearningApp
import com.ejemplo.ingles500.MainActivity
import com.ejemplo.ingles500.R
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.audio.VoicePreferences
import com.ejemplo.ingles500.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: HomeViewModel
    private var ignoreInitialVoiceCallback = true

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val repo = (requireActivity().application as LearningApp).repository
        viewModel = ViewModelProvider(this, RepositoryViewModelFactory(repo))[HomeViewModel::class.java]
        viewModel.stats.observe(viewLifecycleOwner) { stats ->
            binding.tvLearnedCount.text = stats.learnedWords.toString()
            binding.tvDueCount.text = stats.dueWords.toString()
            binding.tvTotalCount.text = getString(R.string.home_total_format, stats.totalWords)
            binding.progressLearning.progress = stats.percentage
            binding.tvPercent.text = getString(R.string.percent_format, stats.percentage)
        }

        val voiceIds = resources.getStringArray(R.array.voice_ids)
        binding.spinnerVoice.adapter = ArrayAdapter.createFromResource(
            requireContext(), R.array.voice_labels, android.R.layout.simple_spinner_item
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        binding.spinnerVoice.setSelection(voiceIds.indexOf(VoicePreferences.selectedId(requireContext())).coerceAtLeast(0))
        binding.spinnerVoice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, selected: View?, position: Int, id: Long) {
                if (ignoreInitialVoiceCallback) {
                    ignoreInitialVoiceCallback = false
                    return
                }
                VoicePreferences.select(requireContext(), voiceIds[position])
                LocalAudioPlayer.playEffect(requireContext(), "click")
            }
        }
        binding.btnPreviewVoice.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            LocalAudioPlayer.playWord(requireContext(), wordId = 1, voiceId = VoicePreferences.selectedId(requireContext()))
        }

        binding.btnStart.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            (activity as? MainActivity)?.navigateTo(R.id.nav_cards)
        }
        binding.btnWriting.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            (activity as? MainActivity)?.navigateTo(R.id.nav_writing)
        }
        binding.btnGame.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            (activity as? MainActivity)?.navigateTo(R.id.nav_games)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
