package com.ejemplo.ingles500.audio

import android.content.Context
import android.media.MediaPlayer
import java.util.Locale

/** Plays only assets packaged inside the APK. Pronunciations and short UI effects use separate players. */
object LocalAudioPlayer {
    private var speechPlayer: MediaPlayer? = null
    private val effectPlayers = linkedSetOf<MediaPlayer>()

    @Synchronized
    fun playWord(context: Context, wordId: Int, voiceId: String = VoicePreferences.selectedId(context)) {
        if (VoicePreferences.presets.none { it.id == voiceId }) return
        val assetName = String.format(Locale.US, "audio/voices/%s/%03d.mp3", voiceId, wordId)
        releasePronunciation()
        createAndPlay(context, assetName, effect = false)
    }

    @Synchronized
    fun playEffect(context: Context, effect: String) {
        val safe = effect.takeIf { it in setOf("click", "page", "correct", "wrong") } ?: "click"
        createAndPlay(context, "audio/effects/$safe.mp3", effect = true)
    }

    /** Stops only the long pronunciation stream when a learning Fragment leaves the screen. */
    @Synchronized
    fun releasePronunciation() {
        speechPlayer?.runCatching { stop() }
        speechPlayer?.release()
        speechPlayer = null
    }

    /** Called when the Activity is destroyed; releases both speech and all short effects. */
    @Synchronized
    fun release() {
        releasePronunciation()
        effectPlayers.toList().forEach { player ->
            player.runCatching { stop() }
            player.release()
        }
        effectPlayers.clear()
    }

    @Synchronized
    private fun createAndPlay(context: Context, assetPath: String, effect: Boolean) {
        val appContext = context.applicationContext
        var player: MediaPlayer? = null
        try {
            val created = MediaPlayer()
            player = created
            appContext.assets.openFd(assetPath).use { descriptor ->
                created.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
            }
            if (effect) effectPlayers.add(created) else speechPlayer = created
            created.setOnPreparedListener { mediaPlayer ->
                runCatching { mediaPlayer.start() }
            }
            created.setOnCompletionListener { finished ->
                synchronized(this) {
                    if (effect) effectPlayers.remove(finished) else if (speechPlayer === finished) speechPlayer = null
                }
                finished.release()
            }
            created.setOnErrorListener { failed, _, _ ->
                synchronized(this) {
                    if (effect) effectPlayers.remove(failed) else if (speechPlayer === failed) speechPlayer = null
                }
                failed.release()
                true
            }
            created.prepareAsync()
        } catch (_: Exception) {
            player?.let { failed ->
                effectPlayers.remove(failed)
                if (speechPlayer === failed) speechPlayer = null
                runCatching { failed.release() }
            }
            // Missing or corrupt audio must never crash a study session.
        }
    }
}
