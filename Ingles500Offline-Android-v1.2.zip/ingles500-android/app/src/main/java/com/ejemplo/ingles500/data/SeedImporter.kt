package com.ejemplo.ingles500.data

import android.content.Context
import org.json.JSONArray

object SeedImporter {
    fun loadWords(context: Context): List<WordEntity> {
        val json = context.assets.open("words.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        return buildList(array.length()) {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    WordEntity(
                        id = item.getInt("id"),
                        english = item.getString("english"),
                        spanish = item.getString("spanish"),
                        example = item.getString("example"),
                        category = item.getString("category")
                    )
                )
            }
        }
    }
}
