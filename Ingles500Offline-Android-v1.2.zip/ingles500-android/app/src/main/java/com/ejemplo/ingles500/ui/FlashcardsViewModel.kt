package com.ejemplo.ingles500.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ejemplo.ingles500.data.WordEntity
import com.ejemplo.ingles500.data.WordRepository
import kotlinx.coroutines.launch
import java.util.Locale

class FlashcardsViewModel(private val repository: WordRepository) : ViewModel() {
    private val _currentWord = MutableLiveData<WordEntity?>()
    val currentWord: LiveData<WordEntity?> = _currentWord

    private val _counter = MutableLiveData("1 / 500")
    val counter: LiveData<String> = _counter

    private val _translationUnlocked = MutableLiveData(false)
    val translationUnlocked: LiveData<Boolean> = _translationUnlocked

    private val _answerFeedback = MutableLiveData("")
    val answerFeedback: LiveData<String> = _answerFeedback

    private var deck: List<WordEntity> = emptyList()
    private var index = -1

    init {
        viewModelScope.launch {
            deck = repository.getStudyOrder()
            showNext()
        }
    }

    fun checkTypedAnswer(answer: String) = checkAnswer(answer, "FLASHCARD_WRITE")
    fun checkSpokenAnswer(answer: String) = checkAnswer(answer, "FLASHCARD_SPEAK")

    private fun checkAnswer(answer: String, mode: String) {
        val word = _currentWord.value ?: return
        if (_translationUnlocked.value == true) return
        val normalized = normalize(answer)
        if (normalized.isBlank()) {
            _answerFeedback.value = "Escribe o pronuncia la palabra antes de comprobarla."
            return
        }
        val correct = normalized == normalize(word.english)
        if (correct) {
            _translationUnlocked.value = true
            _answerFeedback.value = "¡Correcto! Ya puedes comprobar el significado."
            viewModelScope.launch { repository.recordAnswer(word.id, true, mode) }
        } else {
            _answerFeedback.value = "Todavía no coincide. Inténtalo otra vez o salta la tarjeta."
            viewModelScope.launch { repository.recordAnswer(word.id, false, mode) }
        }
    }

    fun skipCard() {
        val word = _currentWord.value ?: return
        if (_translationUnlocked.value == true) return
        viewModelScope.launch {
            repository.recordAnswer(word.id, false, "FLASHCARD_SKIP")
            showNext()
        }
    }

    fun nextAfterCorrect() {
        if (_translationUnlocked.value == true) showNext()
    }

    private fun showNext() {
        if (deck.isEmpty()) return
        index = (index + 1) % deck.size
        _currentWord.value = deck[index]
        _counter.value = "${index + 1} / ${deck.size}"
        _translationUnlocked.value = false
        _answerFeedback.value = ""
    }

    private fun normalize(value: String): String = value
        .trim()
        .lowercase(Locale.US)
        .replace(Regex("[^a-z'\\s]"), "")
        .replace(Regex("\\s+"), " ")
}
