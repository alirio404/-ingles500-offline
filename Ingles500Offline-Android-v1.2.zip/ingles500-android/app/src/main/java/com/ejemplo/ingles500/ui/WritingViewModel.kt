package com.ejemplo.ingles500.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ejemplo.ingles500.data.WordEntity
import com.ejemplo.ingles500.data.WordRepository
import kotlinx.coroutines.launch
import java.util.Locale

class WritingViewModel(private val repository: WordRepository) : ViewModel() {
    private val _currentWord = MutableLiveData<WordEntity?>()
    val currentWord: LiveData<WordEntity?> = _currentWord

    private val _feedback = MutableLiveData<String?>(null)
    val feedback: LiveData<String?> = _feedback

    private val _isCorrect = MutableLiveData<Boolean?>(null)
    val isCorrect: LiveData<Boolean?> = _isCorrect

    private var deck: List<WordEntity> = emptyList()
    private var index = -1

    init {
        viewModelScope.launch {
            deck = repository.getStudyOrder()
            next()
        }
    }

    fun next() {
        if (deck.isEmpty()) return
        index = (index + 1) % deck.size
        _currentWord.value = deck[index]
        _feedback.value = null
        _isCorrect.value = null
    }

    fun checkAnswer(rawAnswer: String) {
        val word = _currentWord.value ?: return
        if (_isCorrect.value == true) return
        val answer = normalize(rawAnswer)
        val expected = normalize(word.english)
        val correct = answer.isNotBlank() && answer == expected
        _isCorrect.value = correct
        _feedback.value = if (correct) {
            "¡Correcto! ${word.english} = ${word.spanish}"
        } else {
            "Todavía no coincide. Revisa la pista e inténtalo otra vez."
        }
        viewModelScope.launch { repository.recordAnswer(word.id, correct, "WRITING") }
    }

    private fun normalize(value: String): String = value
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("[.!?,;:]+$"), "")
        .replace(Regex("\\s+"), " ")
}
