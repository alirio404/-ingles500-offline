package com.ejemplo.ingles500.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "progress",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["id"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ProgressEntity(
    @PrimaryKey val wordId: Int,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val intervalDays: Int = 0,
    val nextReviewAt: Long = 0L,
    val lastReviewedAt: Long = 0L,
    val learned: Boolean = false,
    @ColumnInfo(defaultValue = "0") val streak: Int = 0,
    @ColumnInfo(defaultValue = "0") val attemptCount: Int = 0,
    @ColumnInfo(defaultValue = "'FLASHCARD'") val lastMode: String = "FLASHCARD"
)
