package com.ejemplo.ingles500

import android.app.Application
import androidx.room.Room
import com.ejemplo.ingles500.data.AppDatabase
import com.ejemplo.ingles500.data.WordRepository

class LearningApp : Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(applicationContext, AppDatabase::class.java, "ingles500.db")
            .addMigrations(AppDatabase.MIGRATION_1_2)
            .build()
    }

    val repository: WordRepository by lazy {
        WordRepository(database, applicationContext)
    }
}
