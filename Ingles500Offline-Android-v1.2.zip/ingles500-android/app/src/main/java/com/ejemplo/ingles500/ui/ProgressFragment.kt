package com.ejemplo.ingles500.ui

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.ejemplo.ingles500.LearningApp
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.data.WordRepository
import com.ejemplo.ingles500.databinding.FragmentProgressBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ProgressFragment : Fragment() {
    private var _binding: FragmentProgressBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: ProgressViewModel
    private lateinit var repository: WordRepository

    private val exportBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) writeBackup(uri)
    }
    private val importBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) confirmRestore(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProgressBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        repository = (requireActivity().application as LearningApp).repository
        viewModel = ViewModelProvider(this, RepositoryViewModelFactory(repository))[ProgressViewModel::class.java]
        viewModel.stats.observe(viewLifecycleOwner) { stats ->
            binding.tvProgressLearned.text = stats.learnedWords.toString()
            binding.tvProgressTotal.text = stats.totalWords.toString()
            binding.tvProgressDue.text = stats.dueWords.toString()
            binding.tvProgressReviewed.text = stats.reviewedWords.toString()
            binding.progressAll.progress = stats.percentage
            binding.tvProgressPercent.text = getString(com.ejemplo.ingles500.R.string.percent_format, stats.percentage)
            binding.tvProgressMessage.text = getString(com.ejemplo.ingles500.R.string.progress_message, stats.learnedWords, stats.totalWords)
        }
        binding.btnExportBackup.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            exportBackup.launch("ingles500-respaldo.json")
        }
        binding.btnImportBackup.setOnClickListener {
            LocalAudioPlayer.playEffect(requireContext(), "click")
            importBackup.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
        }
    }

    private fun writeBackup(uri: Uri) {
        val appContext = requireContext().applicationContext
        val repo = repository
        viewLifecycleOwner.lifecycleScope.launch {
            runCatching {
                val json = withContext(Dispatchers.IO) { repo.exportProgressJson() }
                withContext(Dispatchers.IO) {
                    appContext.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
                        ?: error("No se pudo abrir el archivo para guardar.")
                }
            }.onSuccess {
                Toast.makeText(appContext, "Copia de progreso guardada.", Toast.LENGTH_LONG).show()
                LocalAudioPlayer.playEffect(appContext, "correct")
            }.onFailure {
                Toast.makeText(appContext, "No se pudo guardar la copia: ${it.message}", Toast.LENGTH_LONG).show()
                LocalAudioPlayer.playEffect(appContext, "wrong")
            }
        }
    }

    private fun confirmRestore(uri: Uri) {
        AlertDialog.Builder(requireContext())
            .setTitle("Restaurar progreso")
            .setMessage("Se reemplazará el progreso actual por el contenido del archivo. Exporta primero una copia del estado actual si deseas conservarlo.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Restaurar") { _, _ -> restoreFrom(uri) }
            .show()
    }

    private fun restoreFrom(uri: Uri) {
        val appContext = requireContext().applicationContext
        val repo = repository
        viewLifecycleOwner.lifecycleScope.launch {
            runCatching {
                val json = withContext(Dispatchers.IO) {
                    appContext.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("No se pudo leer el archivo.")
                }
                withContext(Dispatchers.IO) { repo.restoreProgressJson(json) }
            }.onSuccess {
                Toast.makeText(appContext, "Progreso restaurado correctamente.", Toast.LENGTH_LONG).show()
                LocalAudioPlayer.playEffect(appContext, "correct")
            }.onFailure {
                Toast.makeText(appContext, "Copia no válida: ${it.message}", Toast.LENGTH_LONG).show()
                LocalAudioPlayer.playEffect(appContext, "wrong")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
