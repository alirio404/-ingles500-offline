package com.ejemplo.ingles500.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ejemplo.ingles500.data.WordEntity
import com.ejemplo.ingles500.data.WordRepository
import kotlinx.coroutines.launch

data class GameQuestion(val prompt: String, val options: List<String>, val correctAnswer: String, val wordId: Int)
data class MatchRound(val left: List<WordEntity>, val right: List<WordEntity>)
data class PhraseTile(val id: Int, val text: String)
data class PhraseChallenge(val word: WordEntity, val tiles: List<PhraseTile>)

class GamesViewModel(private val repository: WordRepository) : ViewModel() {
    private val _question = MutableLiveData<GameQuestion?>()
    val question: LiveData<GameQuestion?> = _question
    private val _feedback = MutableLiveData<String?>(null)
    val feedback: LiveData<String?> = _feedback
    private val _answered = MutableLiveData(false)
    val answered: LiveData<Boolean> = _answered

    private val _matchRound = MutableLiveData<MatchRound?>()
    val matchRound: LiveData<MatchRound?> = _matchRound
    private val _matchedIds = MutableLiveData<Set<Int>>(emptySet())
    val matchedIds: LiveData<Set<Int>> = _matchedIds
    private val _selectedMatchId = MutableLiveData<Int?>(null)
    val selectedMatchId: LiveData<Int?> = _selectedMatchId
    private val _matchFeedback = MutableLiveData<String?>(null)
    val matchFeedback: LiveData<String?> = _matchFeedback
    private val _matchComplete = MutableLiveData(false)
    val matchComplete: LiveData<Boolean> = _matchComplete

    private val _phraseChallenge = MutableLiveData<PhraseChallenge?>()
    val phraseChallenge: LiveData<PhraseChallenge?> = _phraseChallenge
    private val _phraseText = MutableLiveData("")
    val phraseText: LiveData<String> = _phraseText
    private val _phraseFeedback = MutableLiveData("")
    val phraseFeedback: LiveData<String> = _phraseFeedback
    private val _phraseAnswered = MutableLiveData(false)
    val phraseAnswered: LiveData<Boolean> = _phraseAnswered

    private var allWords: List<WordEntity> = emptyList()
    private var reverseMode = false
    private var phraseExpected: List<String> = emptyList()
    private var selectedPhraseTileIds: List<Int> = emptyList()
    private var phraseWrongRecorded = false

    init {
        viewModelScope.launch {
            allWords = repository.getAllWords()
            nextQuestion()
            newMatchRound()
            newPhraseChallenge()
        }
    }

    fun setReverseMode(reverse: Boolean) {
        if (reverseMode != reverse) {
            reverseMode = reverse
            nextQuestion()
        }
    }

    fun nextQuestion() {
        if (allWords.size < 4) return
        val target = allWords.random()
        val correctAnswer = if (reverseMode) target.english else target.spanish
        // Keep four distinct labels; duplicate Spanish glosses made old quiz rounds ambiguous.
        val distractors = allWords.asSequence()
            .filter { it.id != target.id }
            .map { if (reverseMode) it.english else it.spanish }
            .filter { it != correctAnswer }
            .distinct()
            .shuffled()
            .take(3)
            .toList()
        val options = (distractors + correctAnswer).shuffled()
        _question.value = GameQuestion(
            prompt = if (reverseMode) "¿Qué palabra corresponde a: ${target.spanish}?" else "¿Qué significa: ${target.english}?",
            options = options,
            correctAnswer = correctAnswer,
            wordId = target.id
        )
        _feedback.value = null
        _answered.value = false
    }

    fun choose(option: String) {
        val question = _question.value ?: return
        if (_answered.value == true) return
        val correct = option == question.correctAnswer
        _feedback.value = if (correct) "¡Muy bien! Respuesta correcta." else "La respuesta correcta es: ${question.correctAnswer}"
        _answered.value = true
        viewModelScope.launch { repository.recordAnswer(question.wordId, correct, "QUIZ") }
    }

    fun newMatchRound() {
        if (allWords.size < 4) return
        val selected = allWords.shuffled()
            .distinctBy { it.spanish.trim().lowercase() }
            .take(4)
        if (selected.size < 4) return
        _matchRound.value = MatchRound(left = selected, right = selected.shuffled())
        _matchedIds.value = emptySet()
        _selectedMatchId.value = null
        _matchFeedback.value = "Selecciona una palabra en inglés y después su traducción."
        _matchComplete.value = false
    }

    fun selectEnglishForMatch(wordId: Int) {
        if (_matchedIds.value.orEmpty().contains(wordId) || _matchComplete.value == true) return
        _selectedMatchId.value = wordId
        _matchFeedback.value = "Ahora elige la traducción correcta."
    }

    fun selectSpanishForMatch(wordId: Int) {
        val selectedId = _selectedMatchId.value ?: return
        if (_matchComplete.value == true || _matchedIds.value.orEmpty().contains(wordId)) return
        val correct = selectedId == wordId
        viewModelScope.launch { repository.recordAnswer(selectedId, correct, "MATCH") }
        if (correct) {
            val newSet = _matchedIds.value.orEmpty() + wordId
            _matchedIds.value = newSet
            _selectedMatchId.value = null
            _matchFeedback.value = "¡Pareja correcta! (${newSet.size}/4)"
            if (newSet.size == 4) {
                _matchComplete.value = true
                _matchFeedback.value = "¡Completaste las cuatro parejas!"
            }
        } else {
            _matchFeedback.value = "No coinciden. Inténtalo con otra traducción."
        }
    }

    fun newPhraseChallenge() {
        if (allWords.isEmpty()) return
        val target = allWords.filter { word ->
            Regex("\\b${Regex.escape(word.english)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(word.example)
        }.randomOrNull() ?: allWords.random()
        val sourceTokens = target.example.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        phraseExpected = sourceTokens
        val tiles = sourceTokens.mapIndexed { index, token -> PhraseTile(index, token) }.shuffled()
        selectedPhraseTileIds = emptyList()
        phraseWrongRecorded = false
        _phraseChallenge.value = PhraseChallenge(target, tiles)
        _phraseText.value = ""
        _phraseFeedback.value = "Ordena las piezas para formar una frase natural que incluya la palabra objetivo."
        _phraseAnswered.value = false
    }

    fun selectPhraseTile(tileId: Int) {
        val challenge = _phraseChallenge.value ?: return
        if (_phraseAnswered.value == true || selectedPhraseTileIds.contains(tileId)) return
        if (challenge.tiles.none { it.id == tileId }) return
        selectedPhraseTileIds = selectedPhraseTileIds + tileId
        updatePhraseText(challenge)
    }

    fun removeLastPhraseTile() {
        if (_phraseAnswered.value == true || selectedPhraseTileIds.isEmpty()) return
        selectedPhraseTileIds = selectedPhraseTileIds.dropLast(1)
        _phraseChallenge.value?.let(::updatePhraseText)
    }

    fun clearPhrase() {
        if (_phraseAnswered.value == true) return
        selectedPhraseTileIds = emptyList()
        _phraseChallenge.value?.let(::updatePhraseText)
    }

    fun checkPhrase() {
        val challenge = _phraseChallenge.value ?: return
        if (_phraseAnswered.value == true) return
        val tileById = challenge.tiles.associateBy { it.id }
        val built = selectedPhraseTileIds.mapNotNull { tileById[it]?.text }
        if (built == phraseExpected) {
            _phraseAnswered.value = true
            _phraseFeedback.value = "¡Muy bien! La frase está correcta."
            viewModelScope.launch { repository.recordAnswer(challenge.word.id, true, "PHRASE") }
        } else {
            _phraseFeedback.value = "Aún no está en el orden correcto. Puedes mover o quitar piezas e intentarlo de nuevo."
            if (!phraseWrongRecorded) {
                phraseWrongRecorded = true
                viewModelScope.launch { repository.recordAnswer(challenge.word.id, false, "PHRASE") }
            }
        }
    }

    private fun updatePhraseText(challenge: PhraseChallenge) {
        val tileById = challenge.tiles.associateBy { it.id }
        _phraseText.value = selectedPhraseTileIds.mapNotNull { tileById[it]?.text }.joinToString(" ")
    }
}
