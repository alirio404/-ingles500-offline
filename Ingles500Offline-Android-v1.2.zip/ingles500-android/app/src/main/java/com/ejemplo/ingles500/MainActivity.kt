package com.ejemplo.ingles500

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ejemplo.ingles500.databinding.ActivityMainBinding
import com.ejemplo.ingles500.audio.LocalAudioPlayer
import com.ejemplo.ingles500.ui.FlashcardsFragment
import com.ejemplo.ingles500.ui.GamesFragment
import com.ejemplo.ingles500.ui.HomeFragment
import com.ejemplo.ingles500.ui.ProgressFragment
import com.ejemplo.ingles500.ui.WritingFragment
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val repository by lazy { (application as LearningApp).repository }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        binding.bottomNavigationView.isEnabled = false
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { repository.ensureSeeded() }
                binding.bottomNavigationView.isEnabled = true
                binding.bottomNavigationView.setOnItemSelectedListener { item ->
                    LocalAudioPlayer.playEffect(this@MainActivity, "page")
                    showScreen(item.itemId)
                    true
                }
                val selected = if (savedInstanceState == null) R.id.nav_home
                    else savedInstanceState.getInt(STATE_SELECTED, R.id.nav_home)
                binding.bottomNavigationView.selectedItemId = selected
                // Explicitly render the initial selection even if the menu item was already selected.
                showScreen(selected)
            } catch (error: Exception) {
                Snackbar.make(binding.root, getString(R.string.seed_error), Snackbar.LENGTH_LONG).show()
            }
        }
    }

    fun navigateTo(itemId: Int) {
        if (binding.bottomNavigationView.isEnabled) {
            binding.bottomNavigationView.selectedItemId = itemId
        }
    }

    private fun showScreen(itemId: Int) {
        val fragment = when (itemId) {
            R.id.nav_cards -> FlashcardsFragment()
            R.id.nav_writing -> WritingFragment()
            R.id.nav_games -> GamesFragment()
            R.id.nav_progress -> ProgressFragment()
            else -> HomeFragment()
        }
        val title = when (itemId) {
            R.id.nav_cards -> R.string.nav_cards
            R.id.nav_writing -> R.string.nav_writing
            R.id.nav_games -> R.string.nav_games
            R.id.nav_progress -> R.string.nav_progress
            else -> R.string.app_name
        }
        supportActionBar?.title = getString(title)
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(STATE_SELECTED, binding.bottomNavigationView.selectedItemId)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        LocalAudioPlayer.release()
        super.onDestroy()
    }

    companion object {
        private const val STATE_SELECTED = "selected_navigation_item"
    }
}
