package com.ejemplo.ingles500.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Query("SELECT COUNT(*) FROM words")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM words")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(words: List<WordEntity>)

    // Update by primary key rather than REPLACE: REPLACE could delete the parent row
    // and cascade-delete the learner's progress through the foreign key.
    @Update
    suspend fun updateAll(words: List<WordEntity>)

    @Query(
        """
        SELECT w.* FROM words AS w
        LEFT JOIN progress AS p ON p.wordId = w.id
        ORDER BY
            CASE
                WHEN p.wordId IS NOT NULL AND p.nextReviewAt <= :now THEN 0
                WHEN p.wordId IS NULL THEN 1
                ELSE 2
            END,
            COALESCE(p.nextReviewAt, 0),
            w.id
        """
    )
    suspend fun getStudyOrder(now: Long): List<WordEntity>

    @Query("SELECT * FROM words ORDER BY id")
    suspend fun getAllOnce(): List<WordEntity>
}
