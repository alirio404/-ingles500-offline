package com.ejemplo.ingles500.audio

import android.content.Context

/** The six complete, bundled offline voices shipped in app/src/main/assets/audio/voices/. */
data class VoicePreset(val id: String, val label: String, val gender: String, val accent: String)

object VoicePreferences {
    val presets = listOf(
        VoicePreset("m1", "Varón 1 · EE. UU.", "Varón", "Inglés estadounidense"),
        VoicePreset("m2", "Varón 2 · Reino Unido", "Varón", "Inglés británico"),
        VoicePreset("m3", "Varón 3 · Escocia", "Varón", "Inglés escocés"),
        VoicePreset("f1", "Mujer 1 · EE. UU.", "Mujer", "Inglés estadounidense"),
        VoicePreset("f2", "Mujer 2 · EE. UU.", "Mujer", "Inglés estadounidense"),
        VoicePreset("f3", "Mujer 3 · EE. UU.", "Mujer", "Inglés estadounidense")
    )

    fun selectedId(context: Context): String {
        val saved = context.applicationContext
            .getSharedPreferences("voice_settings", Context.MODE_PRIVATE)
            .getString("voice_id", "m1") ?: "m1"
        return presets.firstOrNull { it.id == saved }?.id ?: "m1"
    }

    fun select(context: Context, voiceId: String) {
        if (presets.none { it.id == voiceId }) return
        context.applicationContext.getSharedPreferences("voice_settings", Context.MODE_PRIVATE)
            .edit().putString("voice_id", voiceId).apply()
    }
}
