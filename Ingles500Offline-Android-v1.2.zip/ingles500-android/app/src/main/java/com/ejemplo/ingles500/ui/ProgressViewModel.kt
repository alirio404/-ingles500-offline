package com.ejemplo.ingles500.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.ejemplo.ingles500.data.WordRepository

class ProgressViewModel(repository: WordRepository) : ViewModel() {
    val stats = repository.observeStats().asLiveData()
}
