All six voice folders contain word-numbered MP3 assets (001.mp3 through 500.mp3).

m1 = eSpeak en-us      (male-presenting, US English)
m2 = eSpeak en-gb      (male-presenting, UK English)
m3 = eSpeak en-sc      (male-presenting, Scottish English)
f1 = eSpeak en-us+f1   (female eSpeak voice variant 1)
f2 = eSpeak en-us+f2   (female eSpeak voice variant 2)
f3 = eSpeak en-us+f3   (female eSpeak voice variant 3)

These are synthetic voices generated before packaging. They are not human recordings.
No TTS engine is required on the Android device for playback.
