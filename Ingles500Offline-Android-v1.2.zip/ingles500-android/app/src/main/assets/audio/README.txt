500 clips MP3 de pronunciación inglesa sintética estadounidense (eSpeak) se identifican por ID: 001.mp3 ... 500.mp3.
Los efectos correct.mp3 y wrong.mp3 se usan en respuestas interactivas.
Los assets forman parte del APK; no se descargan en tiempo de ejecución.
