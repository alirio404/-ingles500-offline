#!/usr/bin/env python3
"""Generate bundled, offline speech and UI sound files.

Requirements on the build workstation: eSpeak, Python 3, numpy, lameenc.
Run from the repository root: python tools/generate_audio_assets.py
"""
from __future__ import annotations
import json
import math
import shutil
import subprocess
import tempfile
import wave
from pathlib import Path

import lameenc
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"
WORDS = json.loads((ASSETS / "words.json").read_text(encoding="utf-8"))
SAMPLE_RATE = 22050

VOICES = {
    "m1": "en-us",       # male-presenting, American English
    "m2": "en-gb",       # male-presenting, British English
    "m3": "en-sc",       # male-presenting, Scottish English
    "f1": "en-us+f1",    # female eSpeak variant 1
    "f2": "en-us+f2",    # female eSpeak variant 2
    "f3": "en-us+f3",    # female eSpeak variant 3
}


def encode_mp3(pcm: bytes, out_file: Path, channels: int = 1) -> None:
    encoder = lameenc.Encoder()
    encoder.set_bit_rate(48)
    encoder.set_in_sample_rate(SAMPLE_RATE)
    encoder.set_channels(channels)
    encoder.set_quality(7)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_bytes(encoder.encode(pcm) + encoder.flush())


def create_effects() -> None:
    effects = ASSETS / "audio/effects"
    effects.mkdir(parents=True, exist_ok=True)

    def tone(freq_start: float, duration: float, freq_end: float | None = None,
             amplitude: float = 0.22, second: tuple[float, float, float] | None = None) -> bytes:
        count = int(SAMPLE_RATE * duration)
        t = np.arange(count, dtype=np.float64) / SAMPLE_RATE
        freq_end = freq_start if freq_end is None else freq_end
        inst_freq = np.linspace(freq_start, freq_end, count)
        phase = 2 * np.pi * np.cumsum(inst_freq) / SAMPLE_RATE
        signal = np.sin(phase) * amplitude
        if second is not None:
            f, start, amp = second
            mask = t >= start
            signal[mask] += np.sin(2 * np.pi * f * (t[mask] - start)) * amp
        # Short attack/release envelope, avoids clicks at the file boundary.
        edge = min(int(0.008 * SAMPLE_RATE), max(1, count // 5))
        env = np.ones(count, dtype=np.float64)
        env[:edge] = np.linspace(0, 1, edge)
        env[-edge:] = np.linspace(1, 0, edge)
        pcm = np.clip(signal * env, -1, 1)
        return (pcm * 32767).astype("<i2").tobytes()

    encode_mp3(tone(880, 0.055, amplitude=0.17), effects / "click.mp3")
    encode_mp3(tone(480, 0.13, 760, amplitude=0.18), effects / "page.mp3")
    encode_mp3(tone(640, 0.24, amplitude=0.17, second=(880, 0.105, 0.15)), effects / "correct.mp3")
    encode_mp3(tone(310, 0.20, 185, amplitude=0.19), effects / "wrong.mp3")


def create_voices() -> None:
    audio_root = ASSETS / "audio"
    # Remove the previous single-voice flat files; new paths are audio/voices/<id>/<word-id>.mp3.
    for old in audio_root.glob("[0-9][0-9][0-9].mp3"):
        old.unlink()

    with tempfile.TemporaryDirectory(prefix="ingles500-espeak-") as tmp:
        wav_path = Path(tmp) / "word.wav"
        for voice_id, espeak_voice in VOICES.items():
            target_dir = audio_root / "voices" / voice_id
            target_dir.mkdir(parents=True, exist_ok=True)
            for word in WORDS:
                text = word["english"]
                subprocess.run(
                    ["espeak", "-v", espeak_voice, "-s", "148", "-a", "170", "-w", str(wav_path), text],
                    check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                )
                with wave.open(str(wav_path), "rb") as wav:
                    channels = wav.getnchannels()
                    sample_rate = wav.getframerate()
                    width = wav.getsampwidth()
                    frames = wav.readframes(wav.getnframes())
                if sample_rate != SAMPLE_RATE or channels != 1 or width != 2:
                    raise RuntimeError(f"Unexpected eSpeak WAV format for {text}: {sample_rate=} {channels=} {width=}")
                encode_mp3(frames, target_dir / f"{word['id']:03d}.mp3")
            print(f"Created {len(WORDS)} clips for voice {voice_id} ({espeak_voice})", flush=True)


def main() -> None:
    if shutil.which("espeak") is None:
        raise SystemExit("eSpeak not found. Install it first.")
    create_voices()
    create_effects()
    print("Done: six offline voices and four UI sound effects.")


if __name__ == "__main__":
    main()
