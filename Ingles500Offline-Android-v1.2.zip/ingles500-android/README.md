# Inglés 500 Offline · Android 1.2.0

Aplicación Android nativa en Kotlin, Views XML, ViewBinding, Material 3, Fragments, ViewModels, corrutinas y Room. El vocabulario, la voz y los efectos están dentro del APK. No hay backend.

## Qué cambia en esta versión

- **Progreso persistente:** Room guarda cada respuesta en `ingles500.db`, en el almacenamiento privado de la app. Los datos sobreviven al cierre, reinicio del teléfono y navegación entre pantallas.
- **Migración segura 1 → 2:** `AppDatabase.MIGRATION_1_2` añade campos de racha, cantidad de intentos y modo; conserva los registros existentes. La migración convierte las antiguas marcas `learned = true` en una racha inicial de tres para que el estado aprendido no se pierda.
- **Actualización del vocabulario sin borrar el avance:** la importación usa IDs estables, `INSERT IGNORE` y `UPDATE` por clave primaria. Evita `REPLACE` en la tabla padre, que podría activar la cascada de claves foráneas y borrar progreso.
- **Copia portátil:** desde Progreso se puede exportar o importar un JSON con el historial por palabra. La restauración se valida y se realiza en una transacción; sustituye el progreso actual, no las palabras.
- **Tarjetas de recuerdo activo:** al abrir una tarjeta solo se ve la palabra inglesa. Hay que escribirla correctamente o responder por voz si el dispositivo ofrece reconocimiento local. Solo entonces aparece la traducción y el ejemplo. “Saltar” pasa a la siguiente y registra un repaso fallido.
- **Cuatro modalidades de juego:** opción múltiple inglés → español, español → inglés, emparejar cuatro parejas y ordenar piezas para reconstruir una frase alrededor de una palabra objetivo.
- **Seis voces locales:** tres voces masculinas (EE. UU., Reino Unido y Escocia) y tres variantes femeninas (EE. UU.). Se han incluido 3.000 MP3, uno por palabra y voz. Son síntesis eSpeak, no grabaciones humanas.
- **Efectos locales:** botón, cambio de pantalla, acierto y error.
- **Paleta cromática:** siete colores aproximados tomados como referencia de diseños de personajes; solo se usan como colores de interfaz. No se incluyen personajes, ilustraciones, nombres, logotipos ni otros elementos de esa obra.

## Persistencia: qué se conserva y qué no

Room conserva el progreso mientras Android mantiene los datos privados de la aplicación. Una actualización instalada **encima de la versión anterior** conserva la base de datos si se mantienen el mismo `applicationId` (`com.ejemplo.ingles500`) y la misma firma/keystore, y se incrementa `versionCode`. Esta entrega lo sube a `2` (versión `1.2.0`).

**Desinstalar la aplicación o pulsar “Borrar almacenamiento/datos” elimina la base local.** Para no depender de esa copia privada, abre **Progreso → Exportar progreso** y guarda el JSON en un lugar seguro. Tras reinstalar, usa **Importar copia**. No existe forma de garantizar que Android conserve los datos tras borrar la app; la copia externa es la recuperación.

No se activa copia automática en la nube (`android:allowBackup="false"`). El respaldo lo controla el usuario y puede mantenerse completamente offline.

## Diccionario

`app/src/main/assets/words.json` y `words.csv` contienen 500 entradas con IDs del 1 al 500. He corregido equivalencias que no correspondían al ejemplo, aclarado sentidos contextuales (por ejemplo, *free*, *case*, *line*, *power*, *get*) y sustituido frases plantilla como “I use X in everyday conversations” por ejemplos naturales. La traducción busca dar el sentido que corresponde a la frase mostrada, no enumerar sinónimos indiscriminadamente.

Para conservar la compatibilidad con el progreso de la versión anterior **se mantienen las mismas 500 palabras inglesas y sus IDs**. Por eso no afirmo que esta edición sea un ranking nuevo auditado estadísticamente de las 500 palabras más frecuentes de una transcripción oral. Algunas entradas son expresiones de varias palabras que ya estaban en el conjunto anterior. Reemplazar términos ahora sin una migración semántica haría que el progreso antiguo quedara asociado a otra palabra. El seed está versionado (`SEED_VERSION = 2`) y actualiza traducciones/ejemplos por ID sin borrar progreso.

Si editas el diccionario, conserva los IDs existentes. Para cambiar una palabra inglesa por otra y no transferirle un avance incorrecto, se debe crear una tabla de equivalencias o archivar el avance antiguo antes de publicar un nuevo conjunto.

## Voces y reconocimiento hablado

Las voces de pronunciación son MP3 locales en:

```text
app/src/main/assets/audio/voices/
├── m1/  # masculina, inglés estadounidense
├── m2/  # masculina, inglés británico
├── m3/  # masculina, inglés escocés
├── f1/  # femenina sintética, variante 1
├── f2/  # femenina sintética, variante 2
└── f3/  # femenina sintética, variante 3
```

El selector está en Inicio y la preferencia se guarda localmente. La pronunciación funciona siempre en modo avión porque los clips vienen en el APK.

El botón de respuesta hablada es distinto: usa `SpeechRecognizer.createOnDeviceSpeechRecognizer`, disponible desde Android 12 (API 31), y solo se muestra si el teléfono informa que tiene reconocimiento en el dispositivo. El modelo de reconocimiento offline debe estar instalado en Android. Si el equipo no lo ofrece, el usuario puede escribir la palabra. La aplicación no descarga modelos ni incorpora permiso `INTERNET`; sí solicita `RECORD_AUDIO` al usar el micrófono. La función de escritura no requiere ese permiso.

## Recursos de audio

```text
app/src/main/assets/audio/
├── voices/<m1|m2|m3|f1|f2|f3>/001.mp3 ... 500.mp3
└── effects/
    ├── click.mp3
    ├── page.mp3
    ├── correct.mp3
    └── wrong.mp3
```

Para regenerar las pronunciaciones desde `words.json` instala eSpeak, Python 3, `numpy` y `lameenc`, y ejecuta desde la raíz:

```bash
python -m pip install numpy lameenc
python tools/generate_audio_assets.py
```

La regeneración es opcional: los archivos ya están incluidos. No se necesita eSpeak en los teléfonos ni para compilar el APK.

## Árbol resumido

```text
Ingles500Offline/
├── .github/workflows/android-apk.yml
├── gradlew / gradlew.bat
├── gradle/wrapper/gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── README.md
├── words.csv
├── tools/generate_audio_assets.py
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/words.json
        ├── assets/audio/voices/ (6 × 500 MP3)
        ├── assets/audio/effects/ (4 MP3)
        ├── java/com/ejemplo/ingles500/
        │   ├── LearningApp.kt
        │   ├── MainActivity.kt
        │   ├── audio/LocalAudioPlayer.kt
        │   ├── audio/VoicePreferences.kt
        │   ├── data/AppDatabase.kt
        │   ├── data/ProgressDao.kt
        │   ├── data/ProgressEntity.kt
        │   ├── data/SeedImporter.kt
        │   ├── data/WordDao.kt
        │   ├── data/WordEntity.kt
        │   ├── data/WordRepository.kt
        │   └── ui/ (Fragments, ViewModels y factory)
        └── res/ (layouts, strings, menús, colores, tema y dimensiones)
```

## Requisitos

- Android Studio actualizado que soporte Android Gradle Plugin 8.13.2.
- JDK 17.
- Android SDK Platform 36 y Build Tools 36.0.0.
- Conexión de Internet en el **ordenador de desarrollo** para la primera descarga de Gradle/dependencias. La app instalada funciona sin red.

El script `gradlew` de este proyecto descarga Gradle 8.13 la primera vez y comprueba su SHA-256 antes de ejecutarlo. En Windows se hace lo mismo mediante PowerShell. Después reutiliza la distribución local.

## Compilar en Android Studio

1. Descomprime el ZIP.
2. Abre Android Studio → **Open** → elige la carpeta raíz, donde están `settings.gradle.kts` y `gradlew`.
3. En **Settings → Build Tools → Gradle**, elige JDK 17.
4. En **Tools → SDK Manager**, instala Android SDK Platform 36 y Build Tools 36.0.0.
5. Pulsa **Sync Project with Gradle Files**.
6. Ejecuta en un emulador o dispositivo con Android 6.0 (API 23) o posterior.
7. Para validar el modo offline, activa modo avión y prueba tarjetas, audios, escritura, juegos y progreso.

## Crear APK desde terminal

Linux/macOS:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

Windows PowerShell o CMD:

```bat
gradlew.bat assembleDebug
gradlew.bat assembleRelease
```

Rutas:

```text
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release-unsigned.apk  # si no configuras firma
app/build/outputs/apk/release/app-release.apk           # si configuras firma
```

Debug está firmado con la clave debug que administra Android Gradle. No distribuyas esa APK como release. Para instalar una actualización de una release anterior hace falta la misma clave privada con la que se firmó esa release.

## Crear keystore y firmar release

Crea una clave una sola vez. Guarda el `.jks` y contraseñas fuera del proyecto, con copias de seguridad privadas:

```bash
keytool -genkeypair -v \
  -keystore ingles500-release.jks \
  -alias ingles500 \
  -keyalg RSA -keysize 2048 -validity 10000
```

Linux/macOS:

```bash
export RELEASE_STORE_FILE="$HOME/keys/ingles500-release.jks"
export RELEASE_STORE_PASSWORD="TU_PASSWORD_DEL_KEYSTORE"
export RELEASE_KEY_ALIAS="ingles500"
export RELEASE_KEY_PASSWORD="TU_PASSWORD_DE_LA_CLAVE"
./gradlew assembleRelease
```

PowerShell:

```powershell
$env:RELEASE_STORE_FILE="C:\keys\ingles500-release.jks"
$env:RELEASE_STORE_PASSWORD="TU_PASSWORD_DEL_KEYSTORE"
$env:RELEASE_KEY_ALIAS="ingles500"
$env:RELEASE_KEY_PASSWORD="TU_PASSWORD_DE_LA_CLAVE"
.\gradlew.bat assembleRelease
```

También puedes usar Android Studio → **Build → Generate Signed Bundle / APK → APK**. Conserva siempre la misma clave para publicar actualizaciones. No subas `.jks` ni contraseñas al repositorio.

## GitHub: compilar automáticamente con Actions (recomendado)

1. Crea un repositorio en GitHub, por ejemplo `ingles500-offline`.
2. Desde la carpeta del proyecto, publica el código:

```bash
git init
git add .
git commit -m "Ingles500 Offline v1.2.0"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/ingles500-offline.git
git push -u origin main
```

3. El archivo `.github/workflows/android-apk.yml` ejecuta el build al hacer `push` a `main`/`master`, o manualmente desde **Actions → Build Android APK → Run workflow**.
4. Al terminar, abre la ejecución y baja el artefacto `ingles500-apk`. Sin secretos de firma, la APK Release será unsigned; la Debug es instalable para pruebas.

**Para actualizar una APK instalada sin perder la base:** usa la Release firmada con los secretos de un keystore persistente. La clave Debug de GitHub Actions se genera en un runner temporal y puede cambiar entre ejecuciones; no uses esas APK Debug para actualizar instalaciones anteriores.

### Firma dentro de GitHub Actions (opcional)

Para que GitHub genere una APK Release firmada, crea estos secretos en **Settings → Secrets and variables → Actions → New repository secret**:

- `RELEASE_KEYSTORE_BASE64`: contenido Base64 del `.jks`.
- `RELEASE_STORE_PASSWORD`: contraseña del keystore.
- `RELEASE_KEY_ALIAS`: alias, por ejemplo `ingles500`.
- `RELEASE_KEY_PASSWORD`: contraseña de la clave.

Genera el Base64 sin subir el archivo:

```bash
base64 -w 0 ingles500-release.jks
```

En macOS usa `base64 ingles500-release.jks` y copia el resultado como secreto. El workflow decodifica la clave en el directorio temporal del runner, firma con Gradle y publica el APK como artefacto. Nunca imprimas los secretos en logs ni los añadas al repositorio.

Cada vez que publiques una actualización, incrementa `versionCode` (3, 4, 5...) y cambia `versionName` según corresponda. Mantén `applicationId` y keystore constantes. Así Android puede actualizar la app sobre la instalación previa y Room conserva su base local.

## Privacidad y permisos

El manifiesto declara `RECORD_AUDIO` para responder hablando y marca el micrófono como hardware opcional. No declara `INTERNET`, permisos de almacenamiento, ubicación, Bluetooth, servicios de red, publicidad ni analítica. El audio se lee desde `assets` con `MediaPlayer`. El respaldo se exporta/importa mediante el selector de documentos de Android, sin permiso de almacenamiento general.

## Estado de validación de esta entrega

Se comprobaron estáticamente los 16 XML del proyecto, las referencias a cadenas, la estructura de `words.json` y `words.csv`, los IDs únicos 1–500, los 3.000 archivos MP3 de voz y los cuatro efectos. También se ejecutó una simulación SQLite de la migración 1→2 con una fila aprendida y se verificó que sus contadores y estado permanecen.

**No se generó un APK en el entorno donde se preparó este ZIP.** Ese entorno no tiene Android SDK y no pudo descargar Gradle por falta de acceso DNS al servidor. Para obtener la validación de compilación, ejecuta `./gradlew assembleDebug` en Android Studio/tu ordenador o deja que el workflow de GitHub Actions compile el repositorio. No se debe interpretar la validación estática como prueba de ejecución en un teléfono.
