# Cambios 1.2.0

- Base Room en versión 2, migración 1→2 y conservación de progreso anterior.
- ID y orden de las 500 palabras mantenidos para que `progress.wordId` siga apuntando al mismo término.
- Traducciones más contextuales y reemplazo de ejemplos artificiales por frases naturales.
- Backup de progreso exportable/importable en JSON.
- Tarjetas con traducción oculta hasta respuesta exacta; respuesta escrita o reconocimiento on-device; opción de saltar.
- Seis voces sintéticas MP3 incluidas y cuatro efectos de interfaz.
- Juego de ordenar una frase con una palabra objetivo.
- Firma de release configurable por variables de entorno y workflow de GitHub Actions.
- Menú de modos reorganizado en dos filas para pantallas estrechas.
- Escritura permite reintentos después de un error; se bloquea solo al acertar.
- Se detiene el audio de pronunciación al abandonar las tarjetas y se libera el reproductor si un clip falla.
- GitHub Actions restaura la clave solo cuando está configurado el secreto de firma.
