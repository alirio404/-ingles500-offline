@echo off
setlocal
set GRADLE_VERSION=8.13
set EXPECTED_SHA256=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set "GRADLE_BASE=%GRADLE_USER_HOME%\manual-wrapper"
set "GRADLE_HOME=%GRADLE_BASE%\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
set ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
echo Downloading Gradle %GRADLE_VERSION% from the official server...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'; $actual=(Get-FileHash -Algorithm SHA256 '%ZIP%').Hash.ToLower(); if ($actual -ne '%EXPECTED_SHA256%') { Remove-Item '%ZIP%' -Force; throw 'Gradle SHA-256 mismatch' }; New-Item -ItemType Directory -Force -Path '%GRADLE_BASE%' | Out-Null; Expand-Archive -Force '%ZIP%' '%GRADLE_BASE%'; Remove-Item '%ZIP%' -Force"
if errorlevel 1 exit /b 1
:run
call "%GRADLE_HOME%\bin\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
